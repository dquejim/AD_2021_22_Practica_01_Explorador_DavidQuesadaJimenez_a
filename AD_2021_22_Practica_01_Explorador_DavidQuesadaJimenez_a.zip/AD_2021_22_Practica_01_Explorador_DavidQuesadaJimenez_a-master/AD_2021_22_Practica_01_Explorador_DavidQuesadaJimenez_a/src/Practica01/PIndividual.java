package Practica01;

import java.io.File;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class PIndividual extends javax.swing.JFrame {

    //Para que la ventana se adapte a la pantalla completa,cogemos dos variables,el ancho y el alto de la ventana del usuario
    int ancho= (int) java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth();//Ancho
    int alto= (int) java.awt.Toolkit.getDefaultToolkit().getScreenSize().getHeight();//Alto
    
    public PIndividual() {
        initComponents();
        //Forzamos al JFrame a tener estas dimensiones
        setSize(ancho,alto);
        setLocationRelativeTo(null);
        //Agregamos un título
        setTitle("Explorador de archivos");
        
    }

    @SuppressWarnings("unchecked")
    //Código generado de la interfaz
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        Boton1 = new javax.swing.JButton();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        Boton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Ruta del directorio:");
        jLabel1.setToolTipText("");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(110, 160, 136, 28);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Extensión al filtrar:");
        jLabel2.setToolTipText("");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(110, 280, 136, 28);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Extensión", "Tamaño", "F D"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(320, 410, 730, 230);

        Boton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Practica01/search (3).png"))); // NOI18N
        Boton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Boton1ActionPerformed(evt);
            }
        });
        getContentPane().add(Boton1);
        Boton1.setBounds(1170, 150, 60, 50);

        jTextField2.setBackground(new java.awt.Color(153, 153, 153));
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField2KeyTyped(evt);
            }
        });
        getContentPane().add(jTextField2);
        jTextField2.setBounds(320, 280, 736, 28);

        jTextField3.setBackground(new java.awt.Color(153, 153, 153));
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField3);
        jTextField3.setBounds(320, 160, 740, 30);

        Boton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Practica01/search (3).png"))); // NOI18N
        Boton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Boton2ActionPerformed(evt);
            }
        });
        getContentPane().add(Boton2);
        Boton2.setBounds(1170, 270, 60, 50);

        pack();
    }

    //Acción del primer boto,aquel que introduce los datos en el JTable en base al directorio que seleccionamos
    private void Boton1ActionPerformed(java.awt.event.ActionEvent evt) {

        JFileChooser jfc = new JFileChooser();
        jfc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        int seleccion = jfc.showOpenDialog(this);
        if ( seleccion == JFileChooser.APPROVE_OPTION) {
            String ruta = jfc.getSelectedFile().getPath();
            jTextField3.setText(ruta);
        }

        //Creamos el archivo con esa ruta
        String rt=jTextField3.getText();
        File dir = new File(rt);

        //Creamos un nuevo modelo de JTable,en este caso la cabecera
        DefaultTableModel jTabla = new DefaultTableModel();
        jTabla.addColumn("Nombre");
        jTabla.addColumn("Extensión");
        jTabla.addColumn("Tamaño");
        jTabla.addColumn("F o D");

        //Condicional para saber si la ruta es un directorio o no
        if((dir.exists())&&(dir.isDirectory())){
            //Metenemos en un array de ficheros el interior del directorio seleccionado
            File[] arrayContenido = dir.listFiles();


            //Recorremos el array anterior
            for(int i=0;i<arrayContenido.length;i++){

                String dirfich=null;

                //Si el espacio del Array pertenece a un directorio,añadimos los elementos correspondientes a la tabla que creamos anteriormente
                if(arrayContenido[i].isDirectory()){
                    dirfich="Directorio";
                    String extension=".";
                    jTabla.addRow(new Object[]{arrayContenido[i].getName(),extension,arrayContenido[i].length(),dirfich});
                }

                //Si el espacio del Array pertenece a un fichero,añadimos los elementos correspondientes a la tabla que creamos ante
                if(arrayContenido[i].isFile()){
                    dirfich="Fichero";
                    String extension=arrayContenido[i].getName().substring(arrayContenido[i].getName().lastIndexOf (".") + 1);
                    jTabla.addRow(new Object[]{arrayContenido[i].getName(),extension,arrayContenido[i].length(),dirfich});
                }

                //Igualamos el modelo de la tabla generada al modelo de la tabla que nosotros hemos creado
                jTable1.setModel(jTabla);
            }
        }
        //JDialog que se ejecuta cuando la ruta no pertenece a un directorio
        else{
            JOptionPane.showMessageDialog(null,"Directorio no encontrado");
        }
    }

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {
    }

    private void jTextField2KeyTyped(java.awt.event.KeyEvent evt) {
    }

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {

    }


    //Accion del boton al lado de la extension,que filtra la tabla segun la extension seleccionada (Codigo similar al del boton 1)
    private void Boton2ActionPerformed(java.awt.event.ActionEvent evt) {
        File dir = new File(jTextField3.getText());
        //Metemos la extension seleccionada en la variable filtro
        String filtro = jTextField2.getText();


        DefaultTableModel jTabla = new DefaultTableModel();
        jTabla.addColumn("Nombre");
        jTabla.addColumn("Extensión");
        jTabla.addColumn("Tamaño");
        jTabla.addColumn("F o D");

        if((dir.exists())&&(dir.isDirectory())){
            File[] arrayContenido = dir.listFiles();

            for(int i=0;i<arrayContenido.length;i++){

                String dirfich="";

                if(arrayContenido[i].isDirectory()){
                    dirfich="Directorio";
                    String extension=".";

                    //Condicional para generar en la tabla solo los campos que coincidad en extension con la seleccionada
                    if(extension.equals(filtro)) {
                        jTabla.addRow(new Object[]{arrayContenido[i].getName(), extension, arrayContenido[i].length(), dirfich});
                    }
                }

                //Condicional para generar en la tabla solo los campos que coincidad en extension con la seleccionada
                if(arrayContenido[i].isFile()){
                    dirfich="Fichero";
                    String extension=arrayContenido[i].getName().substring(arrayContenido[i].getName().lastIndexOf (".") + 1);
                    if(extension.equals(filtro)) {
                        jTabla.addRow(new Object[]{arrayContenido[i].getName(), extension, arrayContenido[i].length(), dirfich});
                    }                }

                jTable1.setModel(jTabla);
            }
        }
        else{
            JOptionPane.showMessageDialog(null,"Directorio no encontrado");
        }


        //NOTA: Probé a hacerlo con el código de abajo asi que decidí hacerlo de forma diferente,abajo dejo el código.

        /* TableRowSorter<TableModel> TablaFiltrada = new TableRowSorter<TableModel>(jTable1.getModel());
        jTable1.setRowSorter(TablaFiltrada);

        String extension = jTextField2.getText();
        TablaFiltrada.setRowFilter(RowFilter.regexFilter(extension, 1));*/

    }

    //Código generado por la interfaz
    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PIndividual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PIndividual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PIndividual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PIndividual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PIndividual().setVisible(true);
            }
        });
    }

    private javax.swing.JButton Boton1;
    private javax.swing.JButton Boton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private String ruta;

}
